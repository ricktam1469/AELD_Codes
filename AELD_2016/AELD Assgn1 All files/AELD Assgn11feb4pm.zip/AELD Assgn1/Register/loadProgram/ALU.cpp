#include <iostream>
#include <fstream>
#include <vector>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <stdlib.h>  
#include "ALU.hpp"

ALU::ALU(Registers reg) {
	registers=reg;
	register_location=registers.storage_array;
}

int ALU::execute(int op0,int op1,Operation operation){
	
	//op0=*(register_location);
	//op1=*(register_location+1);
//cout<<op0<<"--->"<<op1;
	switch(operation){
	
		case 0 : return op0+op1;
			 //break;
		case 1 : return op0-op1;
			 //break;
		case 2 : return op0*op1;
			 //break;
		case 3 : try{
					if(op1==0)
						throw op1;
				return op0/op1;
				}
				catch(int i){
					cout<<"Divide by Zero Exception!! Division(op0/op1) is not possible! Program Aborted!"<<endl;
					exit (EXIT_FAILURE);
				}
			//break;
			
			 
		case 4 : if(op0>op1){
				//cout<<"Operand op0 is greater then Operand op1 (op0>op1) \nAnswer is: ";
				registers.ge=1;
				return 1;
			 }
			 else if(op0==op1){
				//cout<<"Oprand op0 and op1 are equal(op0=op1)\nAnswer is: ";
				registers.z=1;				
				return 0;
			 }
			 else{
				cout<<"Operand op0 is less then Operand op1 (op0<op1) \nAnswer is: ";
				return -1;
			 }
			 //break;
		default: cout<<"Check Enumeration\n";
			 break;
	}
	return 0;
}

loadProgram::loadProgram(char *filename){
	file.open(filename, ios::in);

}
void loadProgram::fileReading(){
			
			string line;
			
			while(getline(file,line))
			{
				//cout<<"HI";
				//if(line.find(":")>0)
				//	strcpy(objcommandM32.label,line.substr(0,line.find(":")).c_str());
				//else
				//	objcommandM32.label=NULL;
				char *temp=new char[line.length()+1];
				int i=0;    
		    		char *token;
 		   		strcpy(temp,line.c_str());
 		   		char* receivedDataString[3]={NULL}; //As File is having only 3 Coloumn
				//IF LINE IS BLANK, CONTINUE
				if(line.empty()){
				cout<<"Empty line!\n";
				continue;}
				else{
 			   		token = strtok(temp, " ");
  		  		
					while (token!=NULL)
					{
				    		receivedDataString[i]=token;
				    		//cout << receivedDataString[i] << endl;
				    		token = strtok(NULL, " ");
						i++;
						
    					}
					
				}	//cout<<"i  "<<i;
					objcommandM32.command=receivedDataString[0];
					
					if(receivedDataString[1]!=NULL)
						objcommandM32.operand1=receivedDataString[1];
					else 	
						objcommandM32.operand1=" ";
					if(receivedDataString[2]!=NULL)
					objcommandM32.operand2=receivedDataString[2];
					else 	
						objcommandM32.operand2=" ";
					//objcommandM32.operand2=receivedDataString[2];
					//cout<<"strng"<<receivedDataString[j]<<endl;
					//cout<<"cmd"<<objcommandM32.command<<endl;
					storageVector.push_back(objcommandM32);	
				}
			
			//cout<<storageVector[0];
			
		}

