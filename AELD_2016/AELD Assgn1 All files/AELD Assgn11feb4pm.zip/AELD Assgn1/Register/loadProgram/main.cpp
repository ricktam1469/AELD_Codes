#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <stdlib.h>
#include "ALU.hpp"

using namespace std;
int op0=0,op1=0;
int op0RegAdr,op1RegAdr;
Registers reg;
ALU aluObject(reg);

void parse(char* opr1,char* opr2)
{
//cout<<"parse in";
if(opr1!=NULL) {
	if(opr1[0]=='R') {
			
		op0RegAdr=opr1[1]-'0';
		op0=reg.storage_array[op0RegAdr];
	}
	else
		op0=opr1[0]-'0';
}
else
	op0=0;
if(opr2!=NULL) {
	if(opr2[0]=='R') {
			
		op1RegAdr=opr2[1]-'0';
		op1=reg.storage_array[op1RegAdr];
	}
	else
		op1=opr2[0]-'0';
}
else	
	op1=0;
//cout<<"parse out";
}


void operationExecute(int opnd0,int opnd1,OperationMain opm)
{
switch(opm){
	
		case 0 : reg.storage_array[op0RegAdr]=opnd1;
			 break;
		case 1 : reg.pc=opnd0;
			 break;
		case 2 : reg.pc=opnd0;
			 break;	
		case 3 : reg.pc=opnd0;
			 break;	
		case 4 : reg.pc=opnd0;
			 break;	
		case 5 : reg.pc=opnd0;
			 break;	
			 
		/*case 3 : return op0/op1;
			 break;
		case 4 : if(op0>op1){
				cout<<"Operand op0 is greater then Operand op1 (op0>op1) \nAnswer is: ";
				return 1;
			 }
			 else if(op0==op1){
				cout<<"Oprand op0 and op1 are equal(op0=op1)\nAnswer is: ";
				return 0;
			 }
			 else{
				cout<<"Operand op0 is less then Operand op1 (op0<op1) \nAnswer is: ";
				return -1;
			 }
			 break;*/
		default: cout<<"Check Enumeration\n";
			 break;
	}
}

void performOperation(loadProgram& lp){

const char* operandALU[]={"ADD","SUB","MUL","DIV","CMP"};
const char* operandMain[]={"LOAD","JMP","JNZ","JZ","JGT","JGE","HALT","COUT","COUTALL"};	

lp.fileReading();

		for(int i=0;i<8;i++) {
				//cout<<"chk "<<storageVector[i].label<<endl;
			cout<<"Assembler Command: "<<lp.storageVector[i].command<<"  "<<lp.storageVector[i].operand1<<"  "<<lp.storageVector[i].operand2<<endl;
			for(int k=0;k<11;k++){
				if(k<5)
				if(strcmp(lp.storageVector[i].command,operandALU[k])==0){
					parse(lp.storageVector[i].operand1,lp.storageVector[i].operand2);		
					//cout<<" op0 "<<op0<<"op1 "<<op1;
					if(k==4)
						aluObject.execute(op0,op1,Operation(k));
					else
						reg.storage_array[op0RegAdr]=aluObject.execute(op0,op1,Operation(k));
					cout<<"Array Element: ";
					for(int t=0;t<7;t++)
						cout<<reg.storage_array[t]<<" ";
					cout<<" Zero Flag: "<<aluObject.registers.z;
					cout<<endl<<endl;	
									
				}
				if(strcmp(lp.storageVector[i].command,operandMain[k])==0){
					//cout<<"K="<<operandMain[k]<<endl;
					switch(k){
						case 0: parse(lp.storageVector[i].operand1,lp.storageVector[i].operand2);		
							//cout<<" op0 "<<op0<<"op1 "<<op1;
							operationExecute(op0,op1,LOAD);	
							cout<<"Array Element: ";
							for(int t=0;t<7;t++)
								cout<<reg.storage_array[t]<<" ";
							cout<<" Zero Flag: "<<aluObject.registers.z;
							cout<<endl<<endl;
							break;
						case 1: parse(lp.storageVector[i].operand1,lp.storageVector[i].operand2);		
															
							operationExecute(op0,op1,JMP);
							i=reg.pc-1;
								
							cout<<endl<<endl;
							//goto jump;
							break;
						case 2:	parse(lp.storageVector[i].operand1,lp.storageVector[i].operand2);		
							if(aluObject.registers.z==0) {							
								operationExecute(op0,op1,JNZ);
								i=reg.pc-1;
							}
							else {
								cout<<"Skipped as Zero Flag is set"<<endl<<endl;	     									break;							
							}
							//cout<<endl;
							//goto jump;
							//break;
						case 3: parse(lp.storageVector[i].operand1,lp.storageVector[i].operand2);		
							if(aluObject.registers.z==1) {							
								operationExecute(op0,op1,JZ);
								i=reg.pc-1;
							}
							else {
								cout<<"Skipped as Zero Flag is Not set"<<endl<<endl;	     									break;							
							}
							//cout<<endl;
							//goto jump;
							//break;
						case 4: parse(lp.storageVector[i].operand1,lp.storageVector[i].operand2);		
							if(aluObject.registers.ge==1^aluObject.registers.z) {							
								operationExecute(op0,op1,JGT);
								i=reg.pc-1;
							}
							else {
								cout<<"Skipped"<<endl<<endl;	     									break;							
							}
							//cout<<endl;
							//goto jump;
							//break;
						case 5: parse(lp.storageVector[i].operand1,lp.storageVector[i].operand2);		
							if(aluObject.registers.ge==1) {							
								operationExecute(op0,op1,JGE);
								i=reg.pc-1;
							}
							else {
								cout<<"Skipped"<<endl<<endl;	     									break;							
							}
							//cout<<endl;
							//goto jump;
							//break;
						case 6: return;
						case 7: parse(lp.storageVector[i].operand1,lp.storageVector[i].operand2);		
							//cout<<" op0 "<<op0<<"op1 "<<op1;
							//operationExecute(op0,op1,COUT);	
							cout<<"Array Element at pos: "<< reg.storage_array[op0];
							cout<<endl<<endl;
							break;
						case 8: parse(lp.storageVector[i].operand1,lp.storageVector[i].operand2);		
							//cout<<" op0 "<<op0<<"op1 "<<op1;
							//operationExecute(op0,op1,LOAD);	
							cout<<"Array Element: ";
							for(int t=0;t<16;t++)
								cout<<reg.storage_array[t]<<" ";
							cout<<" Zero Flag: "<<aluObject.registers.z;
							cout<<" Greater Equal Flag: "<<aluObject.registers.ge;
							cout<<endl<<endl;
							break; 
					}	
				}
			}
			
			//switch(x) {
				
				//case 0 : cout<<"In add";break;
			//}
			}


}



int main()
{
	
	
	int op0,op1,n;
	
	cout<<"\n\t WELCOME TO RK ALU "<<endl;
	cout<<"\t ^^^^^^^ ^^ ^^ ^^^ "<<endl<<endl;		
	for(int x=0;x<16;x++) reg.storage_array[x]=0;
	/*cout<<"Enter the value of op0 : ";
	cin>>op0;
	cout<<"Enter the value of op1 : ";
	cin>>op1;
	Reg.storage_array[0]=op0;
	Reg.storage_array[1]=op1;
	aluObject.register_location=Reg.storage_array;*/

	//cout<<"1. ADD\n"<<"2. SUB\n"<<"3. MUL\n"<<"4. DIV\n"<<"5. CMP\n"<<"6. EXIT\n";
	/*while(1){
		cout<<"\nOperation Menu: ( "<<"1. ADD  "<<"2. SUB  "<<"3. MUL  "<<"4. DIV  "<<"5. CMP  "<<"6. EXIT )"<<endl;
		cout<<"Enter your choice(From 1 to 6 For Exit press 6) : ";
		cin>>n;
		switch(n){
			case 1: cout<<"Addition of op0 and op1 (op0+op1) : "<<aluObject.execute(ADD)<<endl;
				break;
			case 2: cout<<"Subtraction of op0 and op1 (op0-op1) : "<<aluObject.execute(SUB)<<endl;
				break;
			case 3: cout<<"Multiplication of op0 and op1 (op0*op1) : "<<aluObject.execute(MUL)<<endl;
				break;
			case 4: try{
					if(op1==0)
						throw op1;
				cout<<"Division of op0 and op1 (op0/op1) : "<<aluObject.execute(DIV)<<endl;
				}
				catch(int i){
					cout<<"Divide by Zero Exception!! Division(op0/op1) is not possible! Try other operation :"<<endl;
				}
				break;
			case 5: cout<<"Comparision of op0 and op1 (op0>op1:1, op0=op1:0, op1<op0:-1)\n";
				cout<<aluObject.execute(CMP)<<endl;
				break;
			case 6: return 0;
			
			default: cout<<"Enter the valid choice."<<endl;
				 break;	
		}
	}*/
char *filename="file.txt";

loadProgram lp(filename);
//loadProgram load;

//lp.fileReading();
performOperation(lp);

cout<<endl;	

return 0;
}
