#include <iostream>
#include "ALU.hpp"

using namespace std;

int main()
{
	Registers Reg;
	ALU aluObject(Reg);
	int op0,op1,n;
	cout<<"Enter the value of op0 : ";
	cin>>op0;
	cout<<"Enter the value of op1 : ";
	cin>>op1;
	Reg.storage_array[0]=op0;
	Reg.storage_array[1]=op1;
	aluObject.register_location=Reg.storage_array;
	//cout<<"1. ADD\n"<<"2. SUB\n"<<"3. MUL\n"<<"4. DIV\n"<<"5. CMP\n"<<"6. EXIT\n";
	while(1){
		cout<<"\nOperation Menu: ( "<<"1. ADD  "<<"2. SUB  "<<"3. MUL  "<<"4. DIV  "<<"5. CMP  "<<"6. EXIT )"<<endl;
		cout<<"Enter your choice(From 1 to 6 For Exit press 6) : ";
		cin>>n;
		switch(n){
			case 1: cout<<"Addition of op0 and op1 (op0+op1) : "<<aluObject.execute(ADD)<<endl;
				break;
			case 2: cout<<"Subtraction of op0 and op1 (op0-op1) : "<<aluObject.execute(SUB)<<endl;
				break;
			case 3: cout<<"Multiplication of op0 and op1 (op0*op1) : "<<aluObject.execute(MUL)<<endl;
				break;
			case 4: try{
					if(op1==0)
						throw op1;
				cout<<"Division of op0 and op1 (op0/op1) : "<<aluObject.execute(DIV)<<endl;
				}
				catch(int i){
					cout<<"Divide by Zero Exception!! Division(op0/op1) is not possible! Try other operation :"<<endl;
				}
				break;
			case 5: cout<<"Comparision of op0 and op1 (op0>op1:1, op0=op1:0, op1<op0:-1)\n";
				cout<<aluObject.execute(CMP)<<endl;
				break;
			case 6: return 0;
			
			default: cout<<"Enter the valid choice."<<endl;
				 break;	
		}
	}	

return 0;
}
