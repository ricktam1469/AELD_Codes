"ALU.hpp' is the given basic class file for declaring the fuctionality.
	A Register class is also added which contains the the array of registers(15).
"ALU.cpp" contains Implementation of the function.
"main.cpp" contains main function for implementing the class and performing Arithmetic operation like 
addition,subtraction,multiplication,division,comparision on operand op0 and op1.
Operands are stored and accessed from register array of Register class
"Makefile" contains compilation commands with proper comments.
