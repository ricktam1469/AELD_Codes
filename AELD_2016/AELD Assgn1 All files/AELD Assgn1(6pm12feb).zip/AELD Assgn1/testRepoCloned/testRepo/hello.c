#include <stdio.h>

// function defination
void hello()
{
	printf("Hello, World! \n"); //print Hello, World! in the output
	
}
