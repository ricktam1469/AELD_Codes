"hello.c' is the basic c program to print Hello world!.
"hello.h" contains function prototype or function declaration with gaurd statements.
"main.c" contains main function.
"Makefile" contains compilation commands with proper comments.
