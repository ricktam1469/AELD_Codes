#include <stdio.h>
#include "hello.h"

int main()
{
	hello(); //calling function hello with void return type
	return 0;
}
