#include <stdio.h>
//using namespace std;

void print_hello()
{
	printf("Hello World Rictam\n");
	

}
