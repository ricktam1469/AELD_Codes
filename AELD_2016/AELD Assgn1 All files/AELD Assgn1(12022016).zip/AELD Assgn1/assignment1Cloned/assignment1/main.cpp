#include <iostream>
#include "ALU.hpp"

using namespace std;

int main()
{
	ALU aluObject;
	char ch;
	int op0,op1,n;
	do{	
		cout<<"Enter the value of op0 : ";
		cin>>op0;
		cout<<"Enter the value of op1 : ";
		cin>>op1;
		while(1) {
			cout<<"\nOperation Menu: ( "<<"1. ADD  "<<"2. SUB  "<<"3. MUL  "<<"4. DIV  "<<"5. CMP  "<<"6. EXIT )"<<endl;
			cout<<"Enter your choice(From 1 to 6) (For exit or enter new operands press 6) : ";
			cin>>n;
			/*op=Operation(n-1); // TypeCasting into Enumuration type
			cout<<aluObject.execute(op0,op1,op)<<endl;*/
			switch(n){
				case 1: cout<<"Addition of op0 and op1 (op0+op1) : "<<aluObject.execute(op0,op1,ADD)<<endl;
					break;
				case 2: cout<<"Subtraction of op0 and op1 (op0-op1) : "<<aluObject.execute(op0,op1,SUB)<<endl;
					break;
				case 3: cout<<"Multiplication of op0 and op1 (op0*op1) : "<<aluObject.execute(op0,op1,MUL)<<endl;
					break;
				case 4: try{
						if(op1==0)
							throw op1;
					cout<<"Division of op0 and op1 (op0/op1) : "<<aluObject.execute(op0,op1,DIV)<<endl;
					}
					catch(int i){
						cout<<"Divide by Zero Exception!! Division(op0/op1) is not possible! Try other operation :"<<endl;
					}
					break;
				case 5: cout<<"Comparision of op0 and op1 (op0>op1:1, op0=op1:0, op1<op0:-1)\n";
					cout<<aluObject.execute(op0,op1,CMP)<<endl;
					break;

				case 6: goto newOperand; 
				
				default: cout<<"Enter the valid choice."<<endl;
					 break;	
			}
			
		}
		newOperand: //label for goto command used in switch case 6
		cout<<"\nWant to enter new operand and continue the operations (y/n)? ";
		cin>>ch;

	} while(ch=='y' || ch=='Y');	

return 0;
}
