#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <stdlib.h>
#include "ALU.hpp"

using namespace std;

//Global Declaration
int op0=0,op1=0;

int op0RegAdr,op1RegAdr;

Registers reg;

ALU aluObject(reg);

/*
 *
 * Extracting operands on the basis of Register name and only specific to R0 to R7
 * Parsing Rn to R and n and getting access to n from the register array by indexes
 * and storing the values in operands	
 */

void parse(char* opr1,char* opr2)
{
//cout<<"parse in";
if(opr1!=NULL) {
	if(opr1[0]=='R') {
			
		op0RegAdr=opr1[1]-'0';
		op0=reg.storage_array[op0RegAdr];
	}
	else
		op0=atoi(opr1);
}
else
	op0=0;
if(opr2!=NULL) {
	if(opr2[0]=='R') {
			
		op1RegAdr=opr2[1]-'0';
		op1=reg.storage_array[op1RegAdr];
	}
	else
		op1=atoi(opr2);
}
else	
	op1=0;
//cout<<"parse out";
}

/*
 *
 * Extracting operation from enum on the basis switch case and 
 * performOperation function pass the values to this function
 *	
 */

void operationExecute(int opnd0,int opnd1,OperationMain opm)
{
	switch(opm){
	
		case 0 : reg.storage_array[op0RegAdr]=opnd1;
			 break;
		case 1 : reg.pc=opnd0;
			 break;
		case 2 : reg.pc=opnd0;
			 break;	
		case 3 : reg.pc=opnd0;
			 break;	
		case 4 : reg.pc=opnd0;
			 break;	
		case 5 : reg.pc=opnd0;
			 break;	
			 
		/*case 3 : return op0/op1;
			 break;
		case 4 : if(op0>op1){
				cout<<"Operand op0 is greater then Operand op1 (op0>op1) \nAnswer is: ";
				return 1;
			 }
			 else if(op0==op1){
				cout<<"Oprand op0 and op1 are equal(op0=op1)\nAnswer is: ";
				return 0;
			 }
			 else{
				cout<<"Operand op0 is less then Operand op1 (op0<op1) \nAnswer is: ";
				return -1;
			 }
			 break;*/
		default: cout<<"Check Enumeration\n";
			 break;
	}
}

/*
 *
 *  
 *	
 */

void performOperation(loadProgram& lp){

const char* operandALU[]={"ADD","SUB","MUL","DIV","CMP"};
const char* operandMain[]={"LOAD","JMP","JNZ","JZ","JGT","JGE","HALT","NOP","COUT","COUTALL"};	
int flag;
lp.fileReading();

		for(int iterate=0;iterate<18;iterate++) {
			flag=0;			
			//cout<<"chk "<<storageVector[iterate].label<<endl;
			cout<<"Assembler Command: "<<lp.storageVector[iterate].command<<"  "<<lp.storageVector[iterate].operand1<<"  "<<lp.storageVector[iterate].operand2<<endl;
			for(int strIterate=0;strIterate<9;strIterate++){
				if(strIterate<5)
				if(strcmp(lp.storageVector[iterate].command,operandALU[strIterate])==0){
					parse(lp.storageVector[iterate].operand1,lp.storageVector[iterate].operand2);		
					//cout<<" op0 "<<op0<<"op1 "<<op1;
					if(strIterate==4)
						aluObject.execute(op0,op1,Operation(strIterate));
					else
						reg.storage_array[op0RegAdr]=aluObject.execute(op0,op1,Operation(strIterate));
					cout<<"Array Element: ";
					for(int arrIterate=0;arrIterate<7;arrIterate++)
						cout<<reg.storage_array[arrIterate]<<" ";
					cout<<" Zero Flag: "<<aluObject.registers.z;
					cout<<" Greater Equal Flag: "<<aluObject.registers.ge;
					cout<<endl<<endl;	
									
				}
				if(strcmp(lp.storageVector[iterate].command,operandMain[strIterate])==0){
					//cout<<"K="<<operandMain[strIterate]<<endl;
					flag=1;
					switch(strIterate){
						case 0: parse(lp.storageVector[iterate].operand1,lp.storageVector[iterate].operand2);		
							//cout<<" op0 "<<op0<<"op1 "<<op1;
							operationExecute(op0,op1,LOAD);	
							cout<<"Array Element: ";
							for(int arrIterate=0;arrIterate<7;arrIterate++)
								cout<<reg.storage_array[arrIterate]<<" ";
							cout<<" Zero Flag: "<<aluObject.registers.z;
							cout<<endl<<endl;
							break;
						case 1: parse(lp.storageVector[iterate].operand1,lp.storageVector[iterate].operand2);													
							operationExecute(op0,op1,JMP);
							iterate=reg.pc-1;
							cout<<" op0 "<<op0<<"op1 "<<op1;	
							cout<<endl<<endl;
							//goto jump;
							break;
						case 2:	parse(lp.storageVector[iterate].operand1,lp.storageVector[iterate].operand2);		
							if(aluObject.registers.z==0) {							
								operationExecute(op0,op1,JNZ);
								iterate=reg.pc-1;
								cout<<"iterate"<<iterate;
								break;
							}
							else {
								cout<<"Skipped as Zero Flag is set"<<endl<<endl;	     									break;							
							}
							//cout<<endl;
							//goto jump;
							//break;
						case 3: parse(lp.storageVector[iterate].operand1,lp.storageVector[iterate].operand2);		
							if(aluObject.registers.z==1) {							
								operationExecute(op0,op1,JZ);
								iterate=reg.pc-1;
								break;
							}
							else {
								cout<<"Skipped as Zero Flag is Not set"<<endl<<endl;	     									break;							
							}
							//cout<<endl;
							//goto jump;
							//break;
						case 4: parse(lp.storageVector[iterate].operand1,lp.storageVector[iterate].operand2);					aluObject.registers.ge==1^aluObject.registers.z;
							if(aluObject.registers.ge==0) {							
								operationExecute(op0,op1,JGT);
								iterate=reg.pc-1;
								break;
							}
							else {
								cout<<"Skipped"<<endl<<endl;	     									break;							
							}
							//cout<<endl;
							//goto jump;
							//break;
						case 5: parse(lp.storageVector[iterate].operand1,lp.storageVector[iterate].operand2);		
							if(aluObject.registers.ge==1) {							
								operationExecute(op0,op1,JGE);
								iterate=reg.pc-1;
								cout<<"iterate"<<iterate;
								break;
							}
							else {
								cout<<"Skipped"<<endl<<endl;	     									break;							
							}
							//cout<<endl;
							//goto jump;
							//break;
						case 6: cout<<"in halt"; return;
						case 7: break;
						case 8: parse(lp.storageVector[iterate].operand1,lp.storageVector[iterate].operand2);		
							//cout<<" op0 "<<op0<<"op1 "<<op1;
							//operationExecute(op0,op1,COUT);	
							cout<<"Array Element at pos: "<< reg.storage_array[op0];
							cout<<endl<<endl;
							break;
						case 9: parse(lp.storageVector[iterate].operand1,lp.storageVector[iterate].operand2);		
							//cout<<" op0 "<<op0<<"op1 "<<op1;
							//operationExecute(op0,op1,COUTALL);	
							cout<<"Array Element: ";
							for(int arrIterate=0;arrIterate<16;arrIterate++)
								cout<<reg.storage_array[arrIterate]<<" ";
							cout<<" Zero Flag: "<<aluObject.registers.z;
							cout<<" Greater Equal Flag: "<<aluObject.registers.ge;
							cout<<endl<<endl;
							break; 
					}	
				}
				if(flag==1) break;
			}
			
			//switch(x) {
				
				//case 0 : cout<<"In add";break;
			//}
			}


}



int main(int argc, char **argsfile)
{
	
	cout<<"\n\t WELCOME TO RK ALU "<<endl;
	cout<<"\t ^^^^^^^ ^^ ^^ ^^^ "<<endl<<endl;		
	for(int arrIterate=0;arrIterate<16;arrIterate++) reg.storage_array[arrIterate]=0;
	/*cout<<"Enter the value of op0 : ";
	cin>>op0;
	cout<<"Enter the value of op1 : ";
	cin>>op1;
	Reg.storage_array[0]=op0;
	Reg.storage_array[1]=op1;
	aluObject.register_location=Reg.storage_array;*/

	//cout<<"1. ADD\n"<<"2. SUB\n"<<"3. MUL\n"<<"4. DIV\n"<<"5. CMP\n"<<"6. EXIT\n";
	/*while(1){
		cout<<"\nOperation Menu: ( "<<"1. ADD  "<<"2. SUB  "<<"3. MUL  "<<"4. DIV  "<<"5. CMP  "<<"6. EXIT )"<<endl;
		cout<<"Enter your choice(From 1 to 6 For Exit press 6) : ";
		cin>>n;
		switch(n){
			case 1: cout<<"Addition of op0 and op1 (op0+op1) : "<<aluObject.execute(ADD)<<endl;
				break;
			case 2: cout<<"Subtraction of op0 and op1 (op0-op1) : "<<aluObject.execute(SUB)<<endl;
				break;
			case 3: cout<<"Multiplication of op0 and op1 (op0*op1) : "<<aluObject.execute(MUL)<<endl;
				break;
			case 4: try{
					if(op1==0)
						throw op1;
				cout<<"Division of op0 and op1 (op0/op1) : "<<aluObject.execute(DIV)<<endl;
				}
				catch(int iterate){
					cout<<"Divide by Zero Exception!! Division(op0/op1) is not possible! Try other operation :"<<endl;
				}
				break;
			case 5: cout<<"Comparision of op0 and op1 (op0>op1:1, op0=op1:0, op1<op0:-1)\n";
				cout<<aluObject.execute(CMP)<<endl;
				break;
			case 6: return 0;
			
			default: cout<<"Enter the valid choice."<<endl;
				 break;	
		}
	}*/

FILE *fileptr;

	if(argsfile[1] == NULL || (fileptr = fopen(argsfile[1], "r")) == NULL){
		printf("Please put a filename in argument %d\n", argc);
		return 0;
	}

	if(fileptr == NULL){
		printf("Can't opening file.\n"); //check if NULL and throw error
		return 0;
	}

loadProgram lp(argsfile[1]);

performOperation(lp);


cout<<endl;	

return 0;
}
