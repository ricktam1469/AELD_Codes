#include <stdio.h>
#include "function.h"

//using namespace std;

int main(){

	print_hello();
  printf( "\n The factorial of 5 is: %d \n", factorial(5));
   return 0;
}
