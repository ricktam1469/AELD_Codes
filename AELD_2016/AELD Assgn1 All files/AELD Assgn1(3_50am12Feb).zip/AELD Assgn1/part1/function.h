int factorial(int n);
void print_hello();
