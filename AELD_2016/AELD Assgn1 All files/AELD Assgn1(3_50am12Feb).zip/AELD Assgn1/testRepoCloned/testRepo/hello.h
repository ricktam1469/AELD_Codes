#ifndef HELLO_H
#define HELLO_H

void hello(); // prototype for function 

#endif /* HELLO_H */
