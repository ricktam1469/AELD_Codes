#include "Tb_alu.hpp"
#include <iostream>

void Tb_alu::source() {

	sc_int<4> temp1,temp2;
	sc_uint<1> temp3;

	
	inp_vld.write(1);

//	cout <<"Enter 1st integer operand(0-15): "<<endl;
//	cin << temp1;
//	cout <<"Enter 2st integer operand(0-15): "<<endl;
//	cin << temp2;
//	cout <<"Enter operation (0-ADD,1-SUB,3-MUL,4-DIV,5-CMP): "<<endl;
//	cin << 	temp3;

//	a.write(temp1);
//	b.write(temp2);
//	operation.write(temp3);

	a.write(10);
	b.write(5);
	operation.write(0);

	do{
	   wait();
	  }while(!inp_rdy.read() );
	inp_vld.write(0);

}//source close

void Tb_alu::sink() {

	sc_int<4> indata;

	output_rdy.write(1);
	do {
	    wait();
	   }while(!output_vld.read() );		
	indata = output.read();
	
	output_rdy.write(0);
	

}// sink close
